+++
# About/Biography widget.

date = "2016-04-20T00:00:00"
draft = false

widget = "about"

# Order that this section will appear in.
weight = 1

# List your academic interests.
[interests]
  interests = [
    "Systems administration",
    "Computer science",
    "Library and Information Sciences (LIS)",
    "High Performance Computing (HPC)",
    "Artificial intelligence",
    "Presenting and Education",
    "Data Mining",
    "Analog computing",
    "Slide Rules"
  ]

# List your qualifications (such as academic degrees).
[[education.courses]]
  course = "Master of Library and Information Science"
  institution = "Indiana University-Purdue University Indianapolis (IUPUI), Indianapolis"
  year = "Dec. 2023"

[[education.courses]]
  course = "Master of Science in Computer Science"
  institution = "University of Tennessee, Knoxville"
  year = 2002

[[education.courses]]
  course = "Bachelor of Science in Computer Science"
  institution = "University of Tennessee, Knoxville"
  year = 1999


+++

# Professional Biography

For over twenty years I've worked as a professional computer scientist with a focus on Linux systems administration.  Within systems administration my focus has been infrastructure systems and development of distribution-agnostic [configuration management](https://en.wikipedia.org/wiki/Software_configuration_management) solutions using [Puppet](https://puppet.com/), [Ansible](https://www.ansible.com/), virtualization, containers, the [HashiCorp](https://www.hashicorp.com/) suite, and both open-source and vendor-designed technologies.

I'm currently engaged as a Senior Systems Administrator with [Leidos](http://www.saic.com), my team working with the Centers for Disease Control and Prevention's (CDC) bioinformatics and [high-performance scientific computing](https://en.wikipedia.org/wiki/Supercomputer) (HPC) group.  This position returns me to the various aspects of HPC/cluster computing, large scale storage, and the specialized technologies and practices needed to supporting researchers and data scientists.

Recently, I was the Princiapl System Administrator of the Linux team in the Systems Operations group at [SAIC](http://www.saic.com/) (Science Applications International Corporation) developing advanced cloud and on-premises solutions utilizing the latest technologies and integration pipelines.

In other positions I've held multiple roles with the U.S. [Department of Energy's](https://www.doe.gov) (DOE)
[Oak Ridge National Lab](https://www.ornl.gov) (ORNL) Systems Operations group at the [National Center for Computational Sciences](https://computing.ornl.gov/nccs.shtml) (NCCS) and also a part of the Research and Development
group supporting the [Neutron Sciences Directorate's](https://neutrons.ornl.gov/) research programs at the [Spallation Neutron Source](https://neutrons.ornl.gov/sns) and [High Flux Isotope Reactor](https://neutrons.ornl.gov/hfir).

While with the [University of Tennessee's](https://www.utk.edu/) [National Institute for Computational Sciences](https://www.nics.tennessee.edu) (NICS) Systems Operations group I held a management role with the [NSF](http://www.nsf.gov/)-funded [Extreme Science and Engineering Discovery Environment](https://www.xsede.org) (XSEDE) project while also maintaining a role of infrastructure team lead and HPC systems manager.

Proudly, I've returned to university studies pursuing a [Master of Library and Information Science](https://en.wikipedia.org/wiki/Master_of_Library_and_Information_Science) (MLIS) degree from [Indiana University–Purdue University Indianapolis](https://www.iupui.edu/) (IUPUI) [Go Jags!].  This will significantly contribute to lifelong goals of enhancing my understanding of knowledge and information, design and application of formal research, facilitated learning experiences, and most importantly the preservation and extension of the core practices and ideals of traditional librarianship.


