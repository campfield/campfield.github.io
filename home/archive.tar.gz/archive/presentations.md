+++
# Selected Publications widget.
# Note: this widget will only display if `content/publication/` contains publications
# with `selected = true` in their `+++` preamble.

date = "2016-04-20T00:00:00"
draft = true

title = "Presentations"
subtitle = ""
widget = "presentations"

# Order that this section will appear in.
weight = 10

# Show publication details (such as abstract)? (true/false)
detailed_list = true

+++
